cookbook
========

Translating recipes from .csv to .html for import into InDesign. Recipes are rough.


Referencing:
http://digitalpublishingtoolkit.org/2014/05/import-html-into-indesign-via-xml/
https://docs.python.org/2/library/csv.html
http://www.pythonforbeginners.com/systems-programming/using-the-csv-module-in-python/

Dictionaries
http://www.dotnetperls.com/dictionary-python